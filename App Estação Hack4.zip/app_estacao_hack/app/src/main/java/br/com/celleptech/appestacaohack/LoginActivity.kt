package br.com.celleptech.appestacaohack

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_login.*


class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        //Executando o clique botão entrar

        btnLoginEntrar.setOnClickListener {

            //Capturar os dados digitados pelo usuário

            val email = edtLoginUsuario.text.toString().trim().toLowerCase()
            val senha = edtLoginSenha.text.toString().trim()

            //Validação dos campos
            if(email.isEmpty()){

                edtLoginUsuario.error = "Campo obrigatório!"
                edtLoginUsuario.requestFocus()

            }else if(senha.isEmpty()){

                 edtLoginSenha.error = "Campo obrigatório"
                 edtLoginSenha.requestFocus()
                
            } else {

                //Acessando o arquivo de preferencias compartilhadas

                val sharedPrefs = getSharedPreferences("cadastro_$email", Context.MODE_PRIVATE)

                //Recuperando email e senha

                val emailPrefs = sharedPrefs.getString("EMAIL", "Chave não encontrada")
                val senhaPrefs = sharedPrefs.getString("SENHA", "Chave não encontrada")


                if (email == emailPrefs && senha == senhaPrefs) {     // verificando email e senha

                    Toast.makeText(this, "Usuário logado!", Toast.LENGTH_LONG).show()

                    //Abrindo a MainActivity

                    val mIntent = Intent(this, MainActivity::class.java)

                    mIntent.putExtra("INTENT_EMAIL", email)
                    startActivity(mIntent)
                    finish()


                } else {
                    //Apresentar uma mensagem de erro ao usuário
                    Toast.makeText(this, "E-mail ou senha inválidos!", Toast.LENGTH_LONG).show()
                }

            }



        }

        //Executando  o clique do botão cadastrar
        btnLoginCadastrar.setOnClickListener {
            //Abrir a tela de cadastro
            val mIntent = Intent(this, CadastroActivity::class.java)
            startActivity(mIntent)
        }






    }
}
